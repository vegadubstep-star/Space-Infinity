SPACE INFINITY — 35 Improved Bass Presets (0.6.3)

Compatible with SPACE INFINITY 0.6.2 or later.

Extract this ZIP. In the synth choose BANK > IMPORT and select any .sipreset file. The ZIP contains 15 offbeat bass stabs, five sub stabs and 15 rolling basses. Play your own MIDI patterns; these sounds are unsequenced. TONE, PUNCH and CHARACTER adjust the body and articulation. Creator and tags are included.

The 0.6.3 Windows installer also includes these sounds in its factory bank.

Every exported preset was reloaded through the native synth and checked against all 1106 parameter values and modulation target properties. The 0.6.2 parameter schema and synth source are unchanged. Musical quality remains a listening choice.
