Actual SPACE INFINITY 0.7.0 native renders. Fixed gain matched to -22 LUFS for comparison only; no additional compression, saturation or EQ.

Acid Comparison: DRY, STANDARD DISTORTION, HOT RANGE. The same MIDI and cutoff automation are used in all three.
Bass Characters: Organ Avenue, Seven Engine, FM Sledge, Acid Ember. All follow the same manually played MIDI pattern.

These examples demonstrate character. The separate Heritage 200 audition ZIP contains each preset at its calibrated native level.
