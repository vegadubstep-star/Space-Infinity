Optional recovery bank of 121 alternatives removed from the main Curated 300 list. Do not import for the default curated palette. Saved projects and personal replacements remain available.
