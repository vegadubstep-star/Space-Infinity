HERITAGE 200 — SPACE INFINITY

200 original presets: 80 workstation/M1 influences, 60 JP-8000/8080 influences,
60 Nord Lead 2 influences. These are interpretations, not manufacturer patches
or component-exact emulations. Existing 160 factory presets remain available.

INSTALL: update SPACE INFINITY to 0.8.0 or later. In its preset manager choose
IMPORT, select this ZIP without extracting it, then choose the Heritage 200 tag.
You can also browse M1 Influence, JP Influence, Nord Influence or role tags.
A second ZIP import updates byte-identical older shipped sounds while preserving
your locally edited sounds, and does not duplicate the collection. To perfect a sound, use REPLACE or SAVE AS. Creator/tags are editable.

Basses follow your MIDI; only the Arps/Motion roles generate notes. TONE opens
the filter; CONTOUR changes filter articulation; SPECTRUM moves the custom table
where used. Every recipe retains the synth's analogue/digital switch and filters.

LEVELS: peak-normalized using maximum-velocity native single-note/retrigger and
four-note chord renders, with pluck OPEN endpoints included. Gain uses measured
clean headroom up to a -0.3 dB true-peak ceiling; perceived LUFS is also measured.
Matching peaks does not make all articulations equally loud to the ear.
The synth retains its final safety stage. Changing macros/effects, playing denser
chords or layering instances can change level; watch the meter while editing.

SOURCES: existing documented CC0 multisamples plus newly synthesized original
waveforms. No Korg, Roland or Nord ROM audio was copied. Built-in multisamples
ship inside the plugin; custom wavetables are embedded in each preset.
These references do not imply endorsement by the named manufacturers.

Technical checks cannot substitute for your musical listening test. Individual
auditions and a category catalogue accompany the release.
