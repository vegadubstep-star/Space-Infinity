LUSH TRANCE 20 — SPACE INFINITY 0.9.0+

In the preset manager select IMPORT and choose this ZIP without extracting it.
Then select the Lush 20 / Lush Trance 20 tag or the Lead category.
The original factory sounds and Heritage 200 remain available.

20 original layered leads with near-zero attack and sustained body.
OPEN brightens and dries the return effects, BODY adds interaction,
HORIZON widens the sound. Several sounds use the A > B oscillator journey.
Creator and tags are editable. SAVE AS keeps the original; REPLACE stores your edit.

Levels use measured native maximum-velocity single notes and chords, all eight
user-macro corners, and 4x true-peak checks for base/all-open phrases. More notes,
extra effects and edits can change level. Watch the output meter while editing.
No artist presets, ROM samples or song melodies have been copied.
